var DATASHEET__CUSTOM__RTD_8ino =
[
    [ "configure_channels", "DATASHEET__CUSTOM__RTD_8ino.html#a4db6dc6482453443a198b8e2cbb1fcb2", null ],
    [ "configure_global_parameters", "DATASHEET__CUSTOM__RTD_8ino.html#af1c27f60a3f5bf845a7684b47a774c5b", null ],
    [ "configure_memory_table", "DATASHEET__CUSTOM__RTD_8ino.html#a6283ec59900d7f957b6de76c1144fe15", null ],
    [ "loop", "DATASHEET__CUSTOM__RTD_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "DATASHEET__CUSTOM__RTD_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ]
];