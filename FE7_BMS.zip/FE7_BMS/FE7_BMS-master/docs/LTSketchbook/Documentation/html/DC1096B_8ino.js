var DC1096B_8ino =
[
    [ "change_VREF", "DC1096B_8ino.html#aa215b3b5bcd388677c1da8296577319b", null ],
    [ "discover_DC1096", "DC1096B_8ino.html#a934eadd66cf19e188a5edd75d9ca01c8", null ],
    [ "loop", "DC1096B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "print_prompt", "DC1096B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1096B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1096B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "square_wave_output", "DC1096B_8ino.html#ab242f606fa8565419207e1a70e6153f7", null ],
    [ "voltage_output", "DC1096B_8ino.html#a5bc05ec3bec03099f53766b48f93a27f", null ],
    [ "VREF1", "DC1096B_8ino.html#a861404e425e342bc07615e246d01fd61", null ],
    [ "VREF2", "DC1096B_8ino.html#a4df04b5bcbfd9db77ac4ed54eacf80be", null ],
    [ "VREF", "DC1096B_8ino.html#ad64537546a996a9e24546764e5c9d1cd", null ]
];