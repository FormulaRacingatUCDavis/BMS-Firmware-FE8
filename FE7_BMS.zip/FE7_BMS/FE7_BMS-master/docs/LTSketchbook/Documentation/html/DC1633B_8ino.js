var DC1633B_8ino =
[
    [ "loop", "DC1633B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "print_prompt", "DC1633B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1633B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1633B_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "setup", "DC1633B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2933_I2C_ADDRESS", "DC1633B_8ino.html#aa1b33a5120570f36f8f7da77081297b4", null ],
    [ "LTC2933_STATUS_WORD", "DC1633B_8ino.html#a7290c6a67eb10afa4e6d33736f0358b6", null ],
    [ "LTC2936_V2_THR", "DC1633B_8ino.html#a798757a7ab78615979485e9662754a56", null ],
    [ "ltc2933_i2c_address", "DC1633B_8ino.html#af7929d70e62a832c2fb14ce9a5bcc43a", null ],
    [ "smbus", "DC1633B_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];