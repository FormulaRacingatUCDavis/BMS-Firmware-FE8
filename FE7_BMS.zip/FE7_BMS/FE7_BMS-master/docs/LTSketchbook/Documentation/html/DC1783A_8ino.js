var DC1783A_8ino =
[
    [ "loop", "DC1783A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1783A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_gain_compression", "DC1783A_8ino.html#a4cb9e09bbff69848a8ed156c47dcedd7", null ],
    [ "menu_3_select_bits", "DC1783A_8ino.html#aca67faed2b6c456abfbe85c454d14022", null ],
    [ "print_prompt", "DC1783A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1783A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1783A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1783A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2380_bits", "DC1783A_8ino.html#a578d4bb5e0878daf5eb52cd28bc10ab4", null ],
    [ "LTC2380_dgc", "DC1783A_8ino.html#a69e6d267c0376e8baf9d8bc8fec3fd45", null ],
    [ "LTC2380_vref", "DC1783A_8ino.html#a1fde9674b347b70ae294e8ef49b16b0d", null ]
];