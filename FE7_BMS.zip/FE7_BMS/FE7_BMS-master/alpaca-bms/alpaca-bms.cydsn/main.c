#include <project.h>
#include <stdint.h>
#include <stdio.h>
#include "cell_interface.h"
#include "current_sense.h"
#include "WDT.h"
#include "data.h"
#include "can_manager.h"
#include "LTC68042.h"
#include "math.h"

#include <time.h>

//#define WDT_ENABLE

#define DEBUG_MODE //TODO: comment this out when running  on actual car
#define USBUART

typedef enum 
{
	BMS_BOOTUP,
	BMS_NORMAL,
	BMS_CHARGEMODE,
	BMS_RACINGMODE,
	BMS_DEBUGMODE,
	BMS_SLEEPMODE,
	BMS_FAULT
}BMS_MODE;

#define BOARD_TEMPS_PER_PACK 15u
#define CELL_TEMPS_PER_PACK 9u
#define TEMPS_PER_PACK 24u

uint8_t cfga_on_init[6];
uint8_t auxa[6];
volatile uint8_t CAN_UPDATE_FLAG=0;
extern volatile BAT_PACK_t bat_pack;
extern BAT_SUBPACK_t bat_subpack[N_OF_SUBPACK];
extern volatile float32 sortedTemps[N_OF_TEMP]; 
extern float32 high_temp_overall;
extern volatile BAT_ERR_t* bat_err_array;
extern volatile uint8_t bat_err_index;
extern volatile uint8_t bat_err_index_loop;
volatile uint8_t CAN_DEBUG=0;
volatile uint8_t RACING_FLAG=0;    // this flag should be set in CAN handler
BAT_SOC_t bat_soc;
Dash_State dash_state = 0;
uint8_t rx_cfg[IC_PER_BUS][8];
void DEBUG_send_cell_voltage();
void DEBUG_send_temp();
void DEBUG_send_current();

volatile double time_spent_start;

int loop_count = 0; // TODO remove when fan controller tests stops
int increment_mode = 1;


CY_ISR(current_update_Handler){
    current_timer_STATUS;
	update_soc();
	return;
}


/*
    Code:
    v = cell voltage
    b = board temp
    t = temp

    //Data sent individually in following format.
    code.subpack_index.index.value
*/
void printUsbData(uint8_t code, uint8_t subpack, uint8_t index, int data)
{
   uint8_t buffer;
    
    //sprintf(buffer, "%c-%c-%c-%c\n", code, subpack, index, data); // TODO: test this (was %c-%u-%u-%u\n)
    //UART_1_PutString(buffer);
    //UART_1_PutChar(code);
    //UART_1_PutChar(subpack);
    //UART_1_PutChar(index);
    
    UART_1_PutChar(0xFF);
    UART_1_PutChar(255 - code);
    UART_1_PutChar(subpack);
    UART_1_PutChar(index);
    for(int i =0; i<4; i++) {
        buffer = data >> (8*i);
        if(buffer == 253 || buffer == 254 || buffer == 255) {
            buffer = 252;
            UART_1_PutChar(data);
            CyDelay(50);
        }
    }
    //UART_1_PutChar(data);
    //UART_1_PutChar(data >> 8);
   // UART_1_PutChar(data >> 16);
   // UART_1_PutChar(data >> 24);
}

uint8 lastHighTemp = 0;
uint8 lastHighSubpack = 0;
uint8 lastHighIndex = 0;
int repeatHighsCount = 0; //count the number of times the same high is reached
int repeatHighNode = 0; //count the number of times in a row the same node is high

void process_event(){
    CyGlobalIntDisable
    // heartbeat
    CyDelay(10);
    can_send_status(0xFE,
    	bat_pack.SOC_percent,
    	bat_pack.status,
    	0,0,0);
    CyDelay(10);
    // send voltage   
    can_send_volt(bat_pack.LO_voltage,
				bat_pack.HI_voltage,
				bat_pack.voltage);
    CyDelay(10);

    #ifdef DEBUG_MODE // Send board and thermistors temperatures over USB
        // send cell voltages 
        for(uint8 subpack = 0; subpack < 6; subpack++) {
            for(uint8 ind = 0; ind < 28; ind++) {
                printUsbData(255 , subpack, ind, bat_pack.subpacks[subpack]->cells[ind]->voltage);
            }
        }
        
        // send board temps
        for(uint8 subpack = 0; subpack < 6; subpack++) {
            for(uint8 ind = 0; ind < 9; ind++) {
                printUsbData(254 , subpack, ind, (bat_pack.subpacks[subpack]->board_temps[ind]->temp_c * 1000));
            }
        }
        
        // send cell temps
        for(uint8 subpack = 0; subpack < 6; subpack++) {
            for(uint8 ind = 0; ind < 15; ind++) {
                printUsbData(253 , subpack, ind, (bat_pack.subpacks[subpack]->temps[ind]->temp_c * 1000));
            }
        }
    #endif
    
    // TEST_DAY_1
    //send temp only if within reasonable range from last temperature

    can_send_temp(bat_pack.subpacks[0]->high_temp,
			bat_pack.subpacks[1]->high_temp,
            bat_pack.subpacks[2]->high_temp,
            bat_pack.subpacks[3]->high_temp,
            bat_pack.subpacks[4]->high_temp,
            //bat_pack.subpacks[5]->high_temp,
            bat_pack.HI_temp_node_index,
			bat_pack.HI_temp_node,
			bat_pack.HI_temp_c);
    
    can_send_volt(bat_pack.LO_voltage, bat_pack.HI_voltage, bat_pack.voltage);
    // send current
    //can_send_current(bat_pack.current);
    CyDelay(10);

    CyGlobalIntEnable;
}

void DEBUG_send_cell_voltage(){
    /*
    uint8_t node, cell;
    for (node = 0; node< N_OF_NODE; node++){
        cell = 0;
        for (cell = 0;cell<14;cell++){
            can_send_volt((node<<8 | cell),
				bat_pack.nodes[node]->cells[cell]->voltage,
				bat_pack.voltage);
            CyDelay(1);
        }
    }
    */
}

void DEBUG_send_temp(){
    /*
    uint8_t node, temp;
    for (node = 0; node< N_OF_NODE; node++){
        temp = 0;
        for (temp = 0;temp<10;temp++){
 //           can_send_temp(temp,
//				node,
//				bat_pack.nodes[node]->temps[temp]->temp_c,
//				bat_pack.nodes[node]->temps[temp]->temp_raw,
  //              bat_pack.HI_temp_c);
            CyDelay(1);
        }
    }
    */
}

void DEBUG_send_current(){
    /*
    uint8_t node, temp;
    for (node = 0; node< N_OF_NODE; node++){
        temp = 0;
        for (temp = 0;temp<10;temp++){
//            can_send_temp(temp,
//				node,
//				bat_pack.nodes[node]->temps[temp]->temp_c,
//				bat_pack.nodes[node]->temps[temp]->temp_raw,
  //              bat_pack.HI_temp_c);
            CyDelay(1);
        }
    }
    */
}


void process_failure_helper(BAT_ERR_t err){
	switch(err.err){
		case CELL_VOLT_OVER:
        	can_send_volt(((err.bad_node<<8) | err.bad_cell),
			    bat_subpack[err.bad_node].cells[err.bad_cell]->voltage, bat_pack.voltage);
		case CELL_VOLT_UNDER:
			can_send_volt(((err.bad_node<<8) | err.bad_cell),
				bat_subpack[err.bad_node].cells[err.bad_cell]->voltage, bat_pack.voltage);
			break;
		case PACK_TEMP_OVER:
		case PACK_TEMP_UNDER:
			// waiting for CAN mesg been defined clearly
			break;

	}
	return;
}

void process_failure(){
	uint8_t i=0;
	// broadcast error in inverse chronological order
	if (bat_err_index_loop){
		// start from bat_err_index back to 0
		for (i=bat_err_index;i>=0;i--){
			process_failure_helper(bat_err_array[i]);
		}
		// start from index=99 to bat_err_index+1
		for (i=99;i>bat_err_index;i--){
			process_failure_helper(bat_err_array[i]);
		}
	}else{
		// start from bat_err_index back to 0
		for (i=bat_err_index;i>=0;i--){
			process_failure_helper(bat_err_array[i]);
		}
	}
}


bool BALANCE_FLAG = true;
BMS_MODE previous_state = BMS_BOOTUP;

int main(void)
{
    // Stablize the BMS OK signal when system is still setting up
    OK_SIG_Write(1);
    SOC_Store_Enable();
    
	// Initialize state machine
	BMS_MODE bms_status = BMS_BOOTUP;
    
	uint32_t system_interval = 0;
    
    FanController_Start();
    FanController_SetDesiredSpeed(1, 0);
    FanController_SetDesiredSpeed(2, 0);
    FanController_SetDesiredSpeed(3, 0);
    FanController_SetDesiredSpeed(4, 0);

    # ifdef DEBUG
    UART_1_Start();
    #endif
    
    //initialize outside of switch case because it won't let me inside of NORMAL before OK_SIG
    time_spent_start = 4294967296;
    
	while(1){
		switch (bms_status){
			case BMS_BOOTUP:
                //current_update_ISR_StartEx(current_update_Handler);
                //current_timer_Start();
				can_init();
				
				#ifdef WDT_ENABLE
                    // TODO Watchdog Timer
			        CyWdtStart(CYWDT_1024_TICKS,CYWDT_LPMODE_NOCHANGE);
                #endif
                                
				// Initialize
                //SOC_Store_Start();
                //SOC_Timer_Start();
				bms_init(MD_FILTERED);
				mypack_init();
                //current_init();              
			    
			    //enable global interrupt
			    CyGlobalIntEnable;
		    
			    //some variables and states
			    OK_SIG_Write(1);
                bms_status = BMS_NORMAL;
                previous_state = BMS_BOOTUP;
				break;

			case BMS_NORMAL:
                
                //begin clock to time normal state
                Timer_1_Start();
                
                // while loop with get volt get temp and bat_balance no delays
                // DCP Enable in 68042.c!!!
			    OK_SIG_Write(1);
                
                // read SOC from EEPROM on bootup
                // send CAN message with SOC
                //if(previous_state == BMS_BOOTUP) {
                   //uint8_t soc = read_rom_soc();
                   //can_send_soc();
                //}
                
			    //check_cfg(rx_cfg);  //CANNOT be finished, because 
				
                /*Only here to check that the old voltage reading still works*/
                bms_init(MD_FILTERED);
                
//                Timer_1_Start(); //check these one at a time
                
		        get_cell_volt();// TODO test voltage
                /*
                Timer_1_Stop();
                uint32 time_left = Timer_1_ReadCounter();
                double time_spent = time_spent_start - (double)time_left;
                time_spent_start = time_left;
                double time_spent_seconds = (double)(time_spent) / (double)(24000000); //gives time in seconds
*/                
				//TESTDAY_2_TODO. check_stack_fuse(); // TODO: check if stacks are disconnected
                
                                
                /*
                    New cell temperature getter
                    1. For each 6811 on each slave
                    2. For mux select 0-7
                    3. wrcfga to set mux select
                    4. adax to convert mux output to digital and store in register
                    5. rdaux to read stored digital value
                
                    Temperature values written to bat_pack.subpacks[subpack]->temps[temp]->temp_c
                */
                bms_init(MD_NORMAL);
                
//                Timer_1_Start();
                
                get_cell_temps_fe6();
                bat_clear_balance(); //TODO : make sure this works!!!!
                
/*                Timer_1_Stop();
                uint32 time_left2 = Timer_1_ReadCounter();
                double time_spent2 = time_spent_start - (double)time_left2;
                time_spent_start = time_left2;
                double time_spent_seconds2 = (double)(time_spent2) / (double)(24000000); //gives time in seconds
*/                
                
#ifdef DEBUG_MODE         
                float32 temperatures[6][24];
                
                // grab all of the temperatures into single array for cleaner processing later
                for(int i = 0; i < 6; i++) {
                    //15 thermistors and 9 board temps per subpack
                    for(int j = 0; j < 15; j++) {
                        temperatures[i][j] = bat_pack.subpacks[i]->temps[j]->temp_c;
                    }
                    for(int j = 15; j < 24; j++) {
                        temperatures[i][j] = bat_pack.subpacks[i]->board_temps[j - 15]->temp_c;
                    }
                }
                
                /* Data structure for tracking cell voltages over time - only used for debugging purposes*/
                uint16_t pack_voltages[6][28];
                uint8_t pack;
                uint8_t cell;
                for (pack = 0; pack < 6; pack++){
                    for (cell = 0; cell < 28; cell++) {
                        pack_voltages[pack][cell] = bat_pack.subpacks[pack]->cells[cell]->voltage;
                    }
                }
#endif
                dash_state = can_rx_dash_stat();
              
                // grab median temperature
                uint8_t medianTemp = (uint8_t)getMedianTemp();
                //uint16 desiredRPM = (bat_pack.HI_temp_c * 650) - (17000);
                uint16 desiredRPM = (medianTemp * 650) - (17000);
                uint16 saturation = 4 * desiredRPM;
                if (desiredRPM > 12500)
                    desiredRPM = 12500;
                
                if (bat_pack.HI_temp_c < 30) { //TODO: check whether to use HI_temp or median temp here
                    FanController_SetDesiredSpeed(1, 0);
                    FanController_SetDesiredSpeed(2, 0);
                    FanController_SetDesiredSpeed(3, 0);
                    FanController_SetDesiredSpeed(4, 0);     
                }
                else if(dash_state == HV_Enabled){
                    FanController_SetSaturation(1, saturation, 0);
                    FanController_SetSaturation(2, saturation, 0);
                    FanController_SetSaturation(3, saturation, 0);
                    FanController_SetSaturation(4, saturation, 0);
                    FanController_SetDesiredSpeed(1, desiredRPM);
                    FanController_SetDesiredSpeed(2, desiredRPM);
                    FanController_SetDesiredSpeed(3, desiredRPM);
                    FanController_SetDesiredSpeed(4, desiredRPM);                     
                }
                else {
                    FanController_SetDesiredSpeed(1, 0);
                    FanController_SetDesiredSpeed(2, 0);
                    FanController_SetDesiredSpeed(3, 0);
                    FanController_SetDesiredSpeed(4, 0);  
                }
                
                CyDelay(10);
                
                // TODO: Calculate SOC
                //get_current(); // TODO get current reading from sensor
			    //bat_soc = get_soc(); // TODO calculate SOC()
				// because it is normal mode, just set a median length current reading interval
			    
                //SKY_TODO update_soc()
 
                
#ifdef BALANCE_ON
                //Uncomment in project.h to balance
                if (bat_pack.HI_temp_board_c >= 60) {
                    BALANCE_FLAG = false;
                } else if (bat_pack.HI_temp_board_c < 55) {
                    BALANCE_FLAG = true;
                }
                
                if (BALANCE_FLAG) {
                    
                    // Turn on cell discharging
                    bat_balance();
                    // Let it discharge for ... seconds
                    CyDelay(10000);
                    //CyDelay(100000000);
                    bat_clear_balance();
                    // Let the boards cool down
                    CyDelay(1000);
                    
                }
#endif
                     
                bat_health_check();
                if (bat_pack.health == FAULT){
					bms_status = BMS_FAULT;
				}

                set_current_interval(100);
				system_interval = 10;
                
                //evaluating time spent in state
                //do these time tests ONE FILE AT A TIME due to the hardcoded variable
                Timer_1_Stop();
                uint32 time_left = Timer_1_ReadCounter();
                double time_spent = time_spent_start - (double)time_left;
                time_spent_start = time_left;
                double time_spent_seconds = (double)(time_spent) / (double)(24000000); //gives time in seconds
                
				break;

/*
			case BMS_CHARGEMODE:
				OK_SIG_Write(1);

				//check_cells();// TODO This function will be finished in get_cell_volt/check stack fuse
		        get_cell_volt();// TODO Get voltage
				check_stack_fuse(); // TODO: check if stacks are disconnected
				get_cell_temp();// TODO Get temperature
				get_current(); // TODO get current reading from sensor
				update_soc(); // TODO calculate SOC()
				// because it is normal mode, just set a median length current reading interval
				bat_health_check();
                set_current_interval(100);
				system_interval = 1000;

                if (bat_pack.health == FAULT){
					bms_status = BMS_FAULT;
				}
				if (!(bat_pack.status || CHARGEMODE)){
					bms_status = CHARGEMODE;
				}
				break;

			case BMS_RACINGMODE:
				OK_SIG_Write(1);

				//check_cells();// TODO This function will be finished in get_cell_volt/check stack fuse
		        get_cell_volt();// TODO Get voltage
				check_stack_fuse(); // TODO: check if stacks are disconnected
				get_cell_temp();// TODO Get temperature
				get_current(); // TODO get current reading from sensor
				bat_soc = get_soc(); // TODO calculate SOC()
                update_soc();
                bat_health_check();
				system_interval = 1000;
				set_current_interval(1);

                
				if (bat_pack.health == FAULT){
					bms_status = BMS_FAULT;
				}
				if (!RACING_FLAG){
					bms_status = BMS_NORMAL;
				}
                
				break;

			case BMS_SLEEPMODE:
				OK_SIG_Write(1);
                bat_health_check();
                if (bat_pack.health == FAULT){
					bms_status = BMS_FAULT;
				}
				break;
*/
			case BMS_FAULT:
				OK_SIG_Write(0u);
				bms_status = BMS_FAULT;
				system_interval = 500;
				process_failure();
                break;
			default:
				bms_status = BMS_FAULT;
                break;
		}
        #ifdef WDT_ENABLE
		    CyWdtClear();
        #endif
		process_event();
		CyDelay(system_interval);
	}
} // main()
